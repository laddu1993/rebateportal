export interface Myrebates {
    rebate_id: string,
    customerinfo: string;
    datecreated: Date;
    refno: string;
    status: string;
    type: string;
    rebate: string;
}
