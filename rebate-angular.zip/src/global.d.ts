// src/global.d.ts
interface Window {
    MSStream: any; // You can use 'any' or define a more specific type if needed
    opera: any;
  }
  