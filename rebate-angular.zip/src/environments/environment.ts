export const environment = {
    production: false,
    enableUrlEncryption: true,
    assetUrl: 'assets/', // Update this path based on your actual setup
    name: "(UAT)",
    apiUrl: `https://crmapps.husqvarnagroup.com/uat_rebate_portal/api/rest/v1.0/`
}